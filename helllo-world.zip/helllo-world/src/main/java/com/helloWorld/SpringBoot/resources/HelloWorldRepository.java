package com.helloWorld.SpringBoot.resources;


import org.springframework.data.repository.CrudRepository;

public interface HelloWorldRepository extends CrudRepository{
}
