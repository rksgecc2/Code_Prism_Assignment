package com.helloWorld.SpringBoot.resources;

public class HelloWorldService {
}
