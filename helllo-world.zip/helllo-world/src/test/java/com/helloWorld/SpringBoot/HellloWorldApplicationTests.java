package com.helloWorld.SpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellloWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
